##encoding=utf8

try:
    from .excel2db import excel2sqlite
except:
    pass