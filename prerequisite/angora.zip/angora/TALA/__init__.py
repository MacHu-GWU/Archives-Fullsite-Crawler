##encoding=UTF8

from .tala import FieldType, Field, Schema, SearchEngine