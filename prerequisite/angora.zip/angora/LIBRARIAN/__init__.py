##encoding=utf-8

from .windowsexplorer import WinFile, WinDir, FileCollections, WinExplorer, string_SizeInBytes
from .winzip import zip_a_folder, zip_everything_in_a_folder, zip_many_files

