##encoding=utf-8

"""
Import Command
--------------
    from util.urlencoder import urlencoder
"""

class UrlEncoder():
    def __init__(self):
        pass
    
    
urlencoder = UrlEncoder()

if __name__ == "__main__":
    import unittest
    class UrlEncoderUnittest(unittest.TestCase):
        pass
    
    unittest.main()