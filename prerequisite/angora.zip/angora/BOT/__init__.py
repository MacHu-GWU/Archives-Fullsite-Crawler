##encoding=UTF8

try:
    from .macro import Bot
except:
    pass