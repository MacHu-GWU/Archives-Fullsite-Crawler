##encoding=utf-8

class MyClass():
    x = [1,2,3]

    def my_method(self, x):
        return x[::-1]